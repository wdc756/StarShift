# Star Shift



A lightweight python class validation library that mimics pydantic's BaseModel dict 
casting validation.

Created by William Dean Coker



## License

This project is licensed under the MIT license, feel free to use or modify this 
project however you like.