# Star Shift



A lightweight python class validation library that mimics Pydantic's `BaseModel` dict 
casting validation, but adds extensive customization and control.

Created by William Dean Coker



## License

This project is licensed under the MIT license, feel free to use or modify this 
project however you like.